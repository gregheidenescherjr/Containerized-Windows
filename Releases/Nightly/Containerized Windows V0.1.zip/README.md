Containerized-Windows

Fedora/Qubes Inspired Project for Windows. I know it will not reach their level but,I am adopting as many ideas as I can to bridge the experience. 

The average person should not have to woory about random attacks on their personal files. This is to help increase best practices for the average user. Advanced users all have their own tweaks.

Unfortunatly, Window and Linux are still still need more growing pains.  With this project, everyone may rethink computer practices, or even the User Interface.

Basically, if you use this Mod/Setup, you are using the same desktop experience as me. A distro/flavor if you will indulge the idea.  

I am big on privacy as far as storing personal information on my computer.  I created my experience initially with Hyper-V.  It still needs work... 

So I switched over to Windows Sandbox and started creating my enviornments to play around. 

The best part of this project is I can focus on my activity without exposing the rest of the PC, within reason.


I do frequently crash my computer and have to restore it often, but I think we can head into a better OS in general.

-----To Do-----

View Issues Link

-----Usage-----

Extract to your desired location of preperation.

Right-Click Install.ps1, Run with Powershell

DO NOT INSTALL THIS YET!!!

Please wait for the first inital full release, and feel free to view the files, the first upload was 5/30/2022.

-----Minimum Requirements-----

***System Requirements***

1. Windows 11.

2. Hardware virtualization.

3. AMD64 architecture.

4. 2 processor cores minimum (4 cores with hyperthreading is recommended).

5. 4GB of RAM (8GB is recommended).

6. 1GB of HDD space (SSD is recommended).

***HHD Space***

1. 500GB is recommended for the Home drive. It will be adding virtual drives inside of your location.

-----Credits-----

Gregory Heidenescher - Creator / Tester

Christopher Southerland - Creator / Tester

-----Special Thanks-----

(VirtualDrives.ps1) Jeffery Hicks @ https://www.altaro.com/hyper-v/creating-generation-2-disk-powershell/

(Sandbox.bat Home Edition) Benny @ https://www.deskmodder.de/blog/2019/04/20/windows-10-home-windows-sandbox-installieren-und-nutzen/

(Hyper-V Home Edition) Usman Khurshid @ https://www.itechtics.com/enable-hyper-v-windows-10-home/

Chris Titus (Chris Titus Tech) - For creating a great toolbox with great reccomendations, applications, and organized tweaks that makes this vision easier.
